from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

@app.route('/')
def puntajes():
    # Conexión a la base de datos y consulta para obtener el top 3 de puntajes por nivel y operación
    conn = sqlite3.connect('C:\\Users\\Freddy Mejia\\Documents\\Universidad Nacional\\Base de datos lll\\Lec10\\Python\\MathRoyale.db')
    cursor = conn.cursor()

    query = """
        SELECT Nombre, Nivel, Puntaje, Tiempo_Jugado, Operación,
               ROW_NUMBER() OVER (PARTITION BY Nivel, Operación ORDER BY Puntaje DESC) AS rank
        FROM PuntajeMasAlto
    """
    cursor.execute(query)
    resultados = cursor.fetchall()

    # Organiza los resultados en un diccionario que Jinja puede recorrer fácilmente
    top_puntajes = {}
    for nombre, nivel, puntaje, tiempo_jugado, operacion, rank in resultados:
        if rank <= 3:
            if nivel not in top_puntajes:
                top_puntajes[nivel] = {}
            if operacion not in top_puntajes[nivel]:
                top_puntajes[nivel][operacion] = []
            top_puntajes[nivel][operacion].append((nombre, puntaje, tiempo_jugado))
    
    conn.close()

    # Pasamos `top_puntajes` en lugar de `puntajes`
    return render_template('tabla_puntajesP.html', puntajes=top_puntajes)

if __name__ == '__main__':
    app.run(debug=True)